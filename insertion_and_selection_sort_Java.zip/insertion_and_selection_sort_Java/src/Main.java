/*
* Ali Arslan
* 1210505017
* */

public class Main {
    public static void main(String[] args) {
        int dizi [] = new int[]{9,4,7,5,2,8,1,3,6};

        selectionSort selectSort = new selectionSort();
        insertionSort insertSort = new insertionSort();

        selectSort.sSort(dizi);
        insertSort.iSort(dizi);


    }
}