/*
 * Ali Arslan
 * 1210505017
 * */

public class insertionSort {
    int dizi [] = new int[]{9,4,7,5,2,8,1,3,6};
    public  void iSort(int dizi[]) {

        for(int i = 1; i < dizi.length; i++) {
            int value = dizi[i];
            int j = i - 1;
            while(j >= 0 && dizi[j] > value) {
                dizi[j + 1] = dizi[j];
                j = j - 1;
            }
            dizi[j + 1] = value;
        }
        System.out.println("___Eklemeli Sıralama___");
        for (int element: dizi) {
            System.out.println(element);
        }
    }
}
