import java.lang.reflect.Array;
/*
 * Ali Arslan
 * 1210505017
 * */
public class selectionSort {
    int dizi [] = new int[]{9,4,7,5,2,8,1,3,6};
    public  void sSort(int dizi[]) {

        for (int i = 0; i < dizi.length; i++) {
            int min = i;
            for (int j = i + 1; j < dizi.length; j++) {
                if (dizi[j] < dizi[min]) {
                    min = j;
                }
            }
            int temp = dizi[i];
            dizi[i] = dizi[min];
            dizi[min] = temp;
        }
        System.out.println("___Seçmeli Sıralama___");
        for (int element: dizi) {
            System.out.println(element);
        }
    }
}
